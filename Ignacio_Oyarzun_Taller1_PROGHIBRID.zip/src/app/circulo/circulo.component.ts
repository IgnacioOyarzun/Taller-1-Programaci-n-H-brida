import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { IonCard, IonItem, IonLabel, IonImg, IonButton, IonInput, IonCardTitle, IonCardHeader, IonCardContent, IonText } from "@ionic/angular/standalone";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-circulo',
  templateUrl: './circulo.component.html',
  styleUrls: ['./circulo.component.scss'],
  standalone: true,
  imports: [IonText, IonCardContent, IonCardHeader, IonCardTitle, IonButton,IonImg, IonCard, IonItem, IonLabel, IonInput, CommonModule, FormsModule ]
})
export class CirculoComponent  implements OnInit {

  resultado: number = 0;
  radio: number = 0;
  constructor() { }

  ngOnInit() {}

  calcularPerimetro()
  {
    this.resultado = 2 * Math.PI * this.radio;
  }
    



}
