import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'taller1.ignaciooyarzun',
  appName: 'taller1-ignaciooyarzun',
  webDir: 'www'
};

export default config;
