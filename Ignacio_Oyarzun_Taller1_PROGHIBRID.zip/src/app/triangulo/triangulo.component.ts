import { Component, OnInit } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle } from "@ionic/angular/standalone";
import { CommonModule } from '@angular/common';
import { IonCard, IonItem, IonLabel, IonImg, IonButton, IonInput, IonCardTitle, IonCardHeader, IonCardContent, IonText } from "@ionic/angular/standalone";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-triangulo',
  templateUrl: './triangulo.component.html',
  styleUrls: ['./triangulo.component.scss'],
  standalone: true,
  imports: [IonTitle, IonToolbar, IonCard, IonItem, IonLabel, IonImg, IonButton, IonInput, IonCardTitle, IonCardHeader, IonCardContent, IonText, FormsModule, ]
})
export class TrianguloComponent  implements OnInit {

  LadoA: number = 0
  LadoB: number = 0
  LadoC: number = 0
  resultado: number = 0
  constructor() { }

  ngOnInit() {}

  calcularPerimetro()
  {
    this.resultado = this.LadoA + this.LadoB + this.LadoC;
  }


}
