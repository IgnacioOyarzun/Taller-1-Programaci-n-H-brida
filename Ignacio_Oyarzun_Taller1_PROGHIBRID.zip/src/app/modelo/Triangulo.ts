// Clase Triangulo Escaleno que Hereda de Figura Geométrica

class TrianguloEscaleno extends FiguraGeometrica
{
    ladoA: number;
    ladoB: number;
    ladoC: number;

    constructor(ladoA: number, ladoB: number, ladoC: number)
    {
        super('Triángulo Escaleno');
        this.ladoA = ladoA;
        this.ladoB = ladoB;
        this.ladoC = ladoC;
    }

    calcularPerimetro(): number
    {
        return this.ladoA + this.ladoB + this.ladoC;
    } 
        
    
}

//Clase Triangulo Equilátero que hereda de la Clase Triángulo Escaleno

class TrianguloEquilatero extends TrianguloEscaleno
{
    constructor(lado: number)
    {
        super(lado, lado, lado);
    }
}